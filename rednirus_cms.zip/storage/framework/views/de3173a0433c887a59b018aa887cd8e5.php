<?php $__env->startSection('content'); ?>

<h1>Cms Of Rednirus Digital Media</h1>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('webapp.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\html code\New folder\rednirus_cms\resources\views\webapp\pages\index.blade.php ENDPATH**/ ?>